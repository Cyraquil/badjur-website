 _               _     _         _   _                                _                                            
| |             | |   (_)       | | | |                              | |                                           
| |     ___  ___| |_   _ _ __   | |_| |__   ___   _ __ ___  _   _ ___| |_ ___ _ __ _   _   _ __ ___   __ _ _______ 
| |    / _ \/ __| __| | | '_ \  | __| '_ \ / _ \ | '_ ` _ \| | | / __| __/ _ \ '__| | | | | '_ ` _ \ / _` |_  / _ \
| |___| (_) \__ \ |_  | | | | | | |_| | | |  __/ | | | | | | |_| \__ \ ||  __/ |  | |_| | | | | | | | (_| |/ /  __/
\_____/\___/|___/\__| |_|_| |_|  \__|_| |_|\___| |_| |_| |_|\__, |___/\__\___|_|   \__, | |_| |_| |_|\__,_/___\___|
                                                             __/ |                  __/ |                           By Cyraquil
                                                            |___/                  |___/                            Ver. 1.1.4
			
###Disclaimer###

This game contain loud noises and scary imagery.

Please take not This software is not a serious project.
But just mainly a little silly project for fun.

###Story###

Cyra decided to set off on an adventure alone to unravel 
the mysteries of the time gears. But weeks have passed and 
she has not been heard from since. Sakura, Cyra's exploration 
partner and best friend. Decided to investigate her disappearance 
and saving Cyra. Maybe...

###How to play###

Find the Time gear and find out their mystery!

###Control###

KEYBOARD/MOUSE:

WASD		- Walk
SHIFT		- Sprint
E			- Interact
LMB			- Shoot
MOUSE		- Look around (horizontal only)

F3			- Toggle FPS counter
F11 		- Toggle FullScreen/Window mode

XBOX ONE/SERIES:

LEFT JOYSTICK	- Walk
LT				- Sprint
A				- Interact
RT				- Shoot
RIGHT JOYSTICK	- Look around (horizontal only)

PLAYSTATION 4/5:

LEFT JOYSTICK	- Walk
L1				- Sprint
X				- Interact
L2				- Shoot
RIGHT JOYSTICK	- Look around (horizontal only)

NINTENDO SWITCH:

LEFT JOYSTICK	- Walk
ZL				- Sprint
B				- Interact
ZR				- Shoot
RIGHT JOYSTICK	- Look around (horizontal only)

###Attribut###

SOFTWARE USE

Game Engine			- Godot Engine 4.4, 4.5
Model				- Blender
Sound software		- Audacity
Art asset			- Aseprite, GIMP

All right of IP, assets, Music is belong to Nintendo, The Pokémon Company, Gamefreak and Spike Chunsoft.